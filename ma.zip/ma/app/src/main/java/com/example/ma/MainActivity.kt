package com.example.ma

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.view.View
import android.view.View.OnClickListener
import android.widget.Toast
import android.widget.TextView

class MainActivity : AppCompatActivity(), OnClickListener {
    private var firstNumber = ""//第一个数字
    private var nextNumber = ""//第二个数字
    private var flag = ""//计算方式
    private lateinit var tv_show: TextView // 声明 TextView 变量

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tv_show = findViewById(R.id.tv_show)

        val btn_c: Button = findViewById<Button>(R.id.btn_c)
        btn_c.setOnClickListener(this)
        val btn_sign: Button = findViewById<Button>(R.id.btn_sign)
        btn_sign.setOnClickListener(this)
        val btn_seven: Button = findViewById<Button>(R.id.btn_seven)
        btn_seven.setOnClickListener(this)
        val btn_eight: Button = findViewById<Button>(R.id.btn_eight)
        btn_eight.setOnClickListener(this)
        val btn_nine: Button = findViewById<Button>(R.id.btn_nine)
        btn_nine.setOnClickListener(this)
        val btn_five: Button = findViewById<Button>(R.id.btn_five)
        btn_five.setOnClickListener(this)
        val btn_four: Button = findViewById<Button>(R.id.btn_four)
        btn_four.setOnClickListener(this)
        val btn_six: Button = findViewById<Button>(R.id.btn_six)
        btn_six.setOnClickListener(this)
        val btn_three: Button = findViewById<Button>(R.id.btn_three)
        btn_three.setOnClickListener(this)
        val btn_two: Button = findViewById<Button>(R.id.btn_two)
        btn_two.setOnClickListener(this)
        val btn_one: Button = findViewById<Button>(R.id.btn_one)
        btn_one.setOnClickListener(this)
        val btn_zreo: Button = findViewById<Button>(R.id.btn_zreo)
        btn_zreo.setOnClickListener(this)
        val btn_multiplication: Button = findViewById<Button>(R.id.btn_multiplication)
        btn_multiplication.setOnClickListener(this)
        val btn_subtract: Button = findViewById<Button>(R.id.btn_subtract)
        btn_subtract.setOnClickListener(this)
        val btn_addition: Button = findViewById<Button>(R.id.btn_addition)
        btn_addition.setOnClickListener(this)
        val btn_equal: Button = findViewById<Button>(R.id.btn_equal)
        btn_equal.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        doClick("" + (v as Button).text)
    }

    fun  doClick(value:String){
        when(value){
            "+","-","*","÷"->{
                if (firstNumber.isNotEmpty() && nextNumber.isEmpty()) {
                    flag = value
                }else if(firstNumber.isNotEmpty() && nextNumber.isNotEmpty()) {
                    flag = value
                    doCount()
                }

            }
            "=" ->{
                if(firstNumber.isNotEmpty() && nextNumber.isNotEmpty()) {
                    doCount()
                    flag = ""
                }
            }
            "C" ->{
                firstNumber = ""
                nextNumber = ""
                tv_show.text = ""
                flag = ""
            }
            else ->{
                if (flag.isNotEmpty()){
                    if (nextNumber.isEmpty() && value == "0" && flag == "÷"){
                        Toast.makeText(this,"除数不能为0",Toast.LENGTH_SHORT).show()
                    }else{
                        nextNumber += value
                        tv_show.text = nextNumber
                    }
                }else{
                    firstNumber += value
                    tv_show.text = firstNumber
                }
            }
        }
    }

    /**
     * 计算方法
     */
    fun doCount(){
        var result = 0.0
        when(flag){
            "+" -> result = firstNumber.toDouble()+nextNumber.toDouble()
            "-" -> result =firstNumber.toDouble()-nextNumber.toDouble()
            "*" -> result =firstNumber.toDouble()*nextNumber.toDouble()
            "÷" -> {
                result = firstNumber.toDouble()/nextNumber.toDouble()
            }
        }
        firstNumber = result.toString()
        nextNumber = ""
        tv_show.text = result.toString()
    }


}


